# Görev API çalışma paketi

Backend Atölyesi için hazırlanmış küçük yerel eğitim projesi. .NET 10 SDK gerekir. ASP.NET Core, C#, EF Core ve SQLite birlikte kullanılır. Paket sürümü 10.0.14 öğretim tabanıdır; gerçek projede desteklenen güncel 10.x güvenlik yamalarını kontrol et.

## Çalıştır

Bu klasörde terminal aç:

```
dotnet restore
dotnet run --urls http://localhost:5088
```

`istekler.http` dosyasını HTTP isteği gönderen editör eklentisiyle açabilir veya curl/Postman gibi araçlarla aynı istekleri gönderebilirsin. İlk çalıştırma yerel `gorevler.db` dosyasını oluşturur. API'yi durdurup başlatınca kayıtlar korunur. Başka bir süreç 5088 portunu kullanıyorsa farklı port seç ve istek dosyasını güncelle.

## İncele

Program.cs içindeki her endpoint'te girdi, doğrulama, veri erişimi ve HTTP sonucunu ayır. Listede filtre, kararlı sıralama, sayfa boyutu sınırı ve CancellationToken var. DTO ile entity farklı tiplerdir. Başlık kuralı tek metotta tutulur.

## Kontrol senaryoları

1. Geçerli POST 201 döndürmeli; yanıttaki Id ile GET aynı başlığı getirmeli.
2. Null, boş, whitespace veya 101 karakterlik başlık 400 dönmeli ve kayıt eklememeli.
3. PUT'ta tamamlandi eksikse 400 dönmeli; "true" metni bool yerine kabul edilmemeli.
4. Olmayan Id ile GET/PUT/DELETE 404 dönmeli.
5. Sayfa 0 veya boyut 51 ile listeleme 400 dönmeli.
6. Bir kaydı güncelleyip uygulamayı yeniden başlatınca güncelleme korunmalı.
7. Başarılı DELETE 204 dönmeli ve ardından GET 404 olmalı.

## Sınırlar ve sonraki adım

Bu yerel eğitim sürümünde kimlik/yetki sistemi yoktur; internete bu haliyle gerçek veriyle açma. `EnsureCreated` ilk kurulum kolaylığı için kullanıldı; aynı veritabanında migrations ile birlikte kullanılmaz. Migration öğrenirken ayrı bir yerel DB ile `EnsureCreated` çağrısını kaldırıp uygun Design paketi ve EF aracı ekleyerek ders adımlarını uygula. SQL Server'a geçerken provider, bağlantı ve migration stratejisini yeniden ele al. `/health` veritabanı sağlığını ölçmez.

## Lisans

Bu özgün eğitim paketi MIT lisansıyla sunulur. Proje klasöründeki LICENSE dosyasını koru. Öğrenme çalışmasını profesyonel iş deneyimi olarak sunma.
