using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<GorevDb>(o => o.UseSqlite("Data Source=gorevler.db"));
builder.Services.AddProblemDetails();
var app = builder.Build();
app.UseExceptionHandler();

// Teaching project: EnsureCreated is convenient for a fresh local database.
// Do not mix it with migration management on the same database.
using (var scope = app.Services.CreateScope())
    await scope.ServiceProvider.GetRequiredService<GorevDb>().Database.EnsureCreatedAsync();

app.MapGet("/health", () => Results.Ok(new { durum = "ok" }));
app.MapGet("/api/gorevler", async (GorevDb db, CancellationToken ct,
    int sayfa = 1, int boyut = 10, bool? tamamlandi = null) =>
{
    if (sayfa is < 1 or > 100000 || boyut is < 1 or > 50)
        return Results.BadRequest(new { hata = "Sayfa 1-100000, boyut 1-50 aralığında olmalı." });
    IQueryable<Gorev> query = db.Gorevler.AsNoTracking();
    if (tamamlandi.HasValue) query = query.Where(g => g.Tamamlandi == tamamlandi.Value);
    var toplam = await query.CountAsync(ct);
    var kayitlar = await query.OrderBy(g => g.Id).Skip((sayfa - 1) * boyut).Take(boyut)
        .Select(g => new GorevYanit(g.Id, g.Baslik, g.Tamamlandi)).ToListAsync(ct);
    return Results.Ok(new { toplam, sayfa, boyut, kayitlar });
});
app.MapGet("/api/gorevler/{id:int}", async (int id, GorevDb db, CancellationToken ct) =>
{
    var g = await db.Gorevler.AsNoTracking().SingleOrDefaultAsync(x => x.Id == id, ct);
    return g is null ? Results.NotFound() : Results.Ok(new GorevYanit(g.Id, g.Baslik, g.Tamamlandi));
});
app.MapPost("/api/gorevler", async (GorevOlustur dto, GorevDb db, CancellationToken ct) =>
{
    var hata = BaslikKurali.Hata(dto.Baslik);
    if (hata is not null) return Results.BadRequest(new { hata });
    var g = new Gorev { Baslik = dto.Baslik!.Trim() };
    db.Gorevler.Add(g);
    await db.SaveChangesAsync(ct);
    return Results.Created($"/api/gorevler/{g.Id}", new GorevYanit(g.Id, g.Baslik, g.Tamamlandi));
});
app.MapPut("/api/gorevler/{id:int}", async (int id, GorevGuncelle dto, GorevDb db, CancellationToken ct) =>
{
    var hata = BaslikKurali.Hata(dto.Baslik);
    if (hata is not null || dto.Tamamlandi is null)
        return Results.BadRequest(new { hata = hata ?? "tamamlandi alanı gerekli." });
    var g = await db.Gorevler.SingleOrDefaultAsync(x => x.Id == id, ct);
    if (g is null) return Results.NotFound();
    g.Baslik = dto.Baslik!.Trim(); g.Tamamlandi = dto.Tamamlandi.Value;
    await db.SaveChangesAsync(ct);
    return Results.Ok(new GorevYanit(g.Id, g.Baslik, g.Tamamlandi));
});
app.MapDelete("/api/gorevler/{id:int}", async (int id, GorevDb db, CancellationToken ct) =>
{
    var g = await db.Gorevler.SingleOrDefaultAsync(x => x.Id == id, ct);
    if (g is null) return Results.NotFound();
    db.Gorevler.Remove(g);
    await db.SaveChangesAsync(ct);
    return Results.NoContent();
});
app.Run();

public record GorevOlustur(string? Baslik);
public record GorevGuncelle(string? Baslik, bool? Tamamlandi);
public record GorevYanit(int Id, string Baslik, bool Tamamlandi);
public class Gorev { public int Id { get; set; } public string Baslik { get; set; } = ""; public bool Tamamlandi { get; set; } }
public class GorevDb(DbContextOptions<GorevDb> options) : DbContext(options) { public DbSet<Gorev> Gorevler => Set<Gorev>(); }
public static class BaslikKurali
{
    public static string? Hata(string? baslik) => string.IsNullOrWhiteSpace(baslik)
        ? "Başlık boş olamaz." : baslik.Trim().Length > 100 ? "Başlık en fazla 100 karakter." : null;
}
